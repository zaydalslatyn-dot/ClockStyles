package com.clockstyles.app

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var list: LinearLayout
    private lateinit var swatchRow: LinearLayout
    private lateinit var preview: ImageView
    private lateinit var hueBar: SeekBar
    private lateinit var shadeBar: SeekBar
    private val gold = 0xFFD4AF37.toInt()
    private val match = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

    private val swatches = intArrayOf(
        0xFFFFFFFF.toInt(), 0xFFC8C8C8.toInt(), 0xFF111111.toInt(), 0xFFD4AF37.toInt(),
        0xFFFF9800.toInt(), 0xFFE53935.toInt(), 0xFFEC407A.toInt(), 0xFF8E24AA.toInt(),
        0xFF3F51B5.toInt(), 0xFF3B8BE6.toInt(), 0xFF00BCD4.toInt(), 0xFF43A047.toInt(),
        0xFFCDDC39.toInt()
    )

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(fill: Int, stroke: Int, strokeW: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = dp(16).toFloat()
        if (strokeW > 0) g.setStroke(strokeW, stroke)
        return g
    }

    private fun label(text: String, topDp: Int): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 14f
        t.setTextColor(0xFF9A9BA0.toInt())
        val lp = LinearLayout.LayoutParams(match, wrap)
        lp.topMargin = dp(topDp)
        t.layoutParams = lp
        return t
    }

    private fun gradBar(colors: IntArray): GradientDrawable {
        val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, colors)
        g.cornerRadius = dp(10).toFloat()
        return g
    }

    private fun previewBg(col: Int): Int =
        if (Draw.lum(col) > 0.5f) 0xFF2A2A2D.toInt() else 0xFFCFCFCF.toInt()

    private fun effectiveColor(st: ClockStyle): Int = Prefs.color(this) ?: st.defColor

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(0xFF0E0E10.toInt())
        scroll.layoutDirection = View.LAYOUT_DIRECTION_RTL

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(36), dp(16), dp(28))
        scroll.addView(root, ViewGroup.LayoutParams(match, wrap))

        val title = TextView(this)
        title.text = "أشكال الساعة"
        title.textSize = 24f
        title.setTextColor(Color.WHITE)
        title.typeface = Typeface.DEFAULT_BOLD
        root.addView(title)

        preview = ImageView(this)
        preview.scaleType = ImageView.ScaleType.FIT_CENTER
        preview.setPadding(dp(8), dp(8), dp(8), dp(8))
        val plp = LinearLayout.LayoutParams(match, dp(200))
        plp.topMargin = dp(16)
        root.addView(preview, plp)

        val sw = Switch(this)
        sw.text = "أرقام عربية"
        sw.setTextColor(Color.WHITE)
        sw.isChecked = Prefs.arabic(this)
        sw.setOnCheckedChangeListener { _, v ->
            Prefs.setArabic(this, v)
            ClockWidgetProvider.updateAll(this)
            refresh()
        }
        val slp = LinearLayout.LayoutParams(match, wrap)
        slp.topMargin = dp(16)
        root.addView(sw, slp)

        val add = Button(this)
        add.text = "إضافة الويدجت للشاشة الرئيسية"
        add.setOnClickListener { pin() }
        val alp = LinearLayout.LayoutParams(match, wrap)
        alp.topMargin = dp(12)
        root.addView(add, alp)

        root.addView(label("اللون", 20))

        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        swatchRow = LinearLayout(this)
        swatchRow.orientation = LinearLayout.HORIZONTAL
        hs.addView(swatchRow)
        root.addView(hs, LinearLayout.LayoutParams(match, wrap))

        root.addView(label("لون مخصص (اسحب لاختيار اللون)", 8))
        hueBar = SeekBar(this)
        hueBar.max = 360
        hueBar.progress = Prefs.hue(this)
        hueBar.layoutDirection = View.LAYOUT_DIRECTION_LTR
        hueBar.progressDrawable = ColorDrawable(Color.TRANSPARENT)
        hueBar.background = gradBar(IntArray(7) { i -> Color.HSVToColor(floatArrayOf(i * 60f, 1f, 1f)) })
        root.addView(hueBar, LinearLayout.LayoutParams(match, dp(34)))

        root.addView(label("الدرجة (من الغامق إلى الفاتح)", 8))
        shadeBar = SeekBar(this)
        shadeBar.max = 100
        shadeBar.progress = Prefs.shade(this)
        shadeBar.layoutDirection = View.LAYOUT_DIRECTION_LTR
        shadeBar.progressDrawable = ColorDrawable(Color.TRANSPARENT)
        root.addView(shadeBar, LinearLayout.LayoutParams(match, dp(34)))
        updateShadeBg()

        hueBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) {
                    Prefs.setHue(this@MainActivity, p)
                    updateShadeBg()
                    applyCustomColor()
                }
            }

            override fun onStartTrackingTouch(sb: SeekBar) {}

            override fun onStopTrackingTouch(sb: SeekBar) {
                refresh()
            }
        })
        shadeBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) {
                    Prefs.setShade(this@MainActivity, p)
                    applyCustomColor()
                }
            }

            override fun onStartTrackingTouch(sb: SeekBar) {}

            override fun onStopTrackingTouch(sb: SeekBar) {
                refresh()
            }
        })

        val reset = Button(this)
        reset.text = "اللون الأصلي لكل شكل"
        reset.setOnClickListener {
            Prefs.clearColor(this)
            ClockWidgetProvider.updateAll(this)
            refresh()
        }
        val rlp = LinearLayout.LayoutParams(match, wrap)
        rlp.topMargin = dp(8)
        root.addView(reset, rlp)

        root.addView(label("اضغط على أي شكل وتتحدث الساعة مباشرة", 20))

        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        root.addView(list, LinearLayout.LayoutParams(match, wrap))

        setContentView(scroll)
        refresh()
    }

    private fun updateShadeBg() {
        val h = Prefs.hue(this)
        shadeBar.background = gradBar(
            intArrayOf(0xFF000000.toInt(), Draw.shadeColor(h, 50), 0xFFFFFFFF.toInt())
        )
    }

    private fun applyCustomColor() {
        Prefs.setColor(this, Draw.shadeColor(Prefs.hue(this), Prefs.shade(this)))
        ClockWidgetProvider.updateAll(this)
        refreshPreview()
    }

    private fun refreshPreview() {
        val st = Prefs.style(this)
        preview.background = rounded(previewBg(effectiveColor(st)), 0, 0)
        preview.setImageBitmap(Renderer.render(this, st, dp(340), dp(180)))
    }

    private fun refreshSwatches() {
        swatchRow.removeAllViews()
        val cur = Prefs.color(this)
        for (cc in swatches) {
            val v = View(this)
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(cc)
            g.setStroke(dp(if (cur == cc) 3 else 1), if (cur == cc) gold else 0xFF555555.toInt())
            v.background = g
            val lp = LinearLayout.LayoutParams(dp(38), dp(38))
            lp.setMargins(dp(4), dp(8), dp(4), dp(8))
            v.setOnClickListener {
                Prefs.setColor(this, cc)
                ClockWidgetProvider.updateAll(this)
                refresh()
            }
            swatchRow.addView(v, lp)
        }
    }

    private fun refresh() {
        val cur = Prefs.styleId(this)
        refreshPreview()
        refreshSwatches()
        list.removeAllViews()
        for (st in Styles.all) {
            val sel = st.id == cur
            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            card.background = rounded(0xFF1B1B1D.toInt(), gold, if (sel) dp(2) else 0)
            card.setPadding(dp(10), dp(10), dp(10), dp(10))

            val img = ImageView(this)
            img.background = rounded(previewBg(effectiveColor(st)), 0, 0)
            img.setImageBitmap(Renderer.render(this, st, dp(300), dp(120)))
            card.addView(img, LinearLayout.LayoutParams(match, dp(120)))

            val tv = TextView(this)
            tv.text = (if (sel) "✓ " else "") + st.name
            tv.textSize = 14f
            tv.setTextColor(if (sel) gold else Color.WHITE)
            val vlp = LinearLayout.LayoutParams(match, wrap)
            vlp.topMargin = dp(6)
            card.addView(tv, vlp)

            card.setOnClickListener {
                Prefs.setStyle(this, st.id)
                ClockWidgetProvider.updateAll(this)
                refresh()
            }

            val clp = LinearLayout.LayoutParams(match, wrap)
            clp.topMargin = dp(10)
            list.addView(card, clp)
        }
    }

    private fun pin() {
        val mgr = AppWidgetManager.getInstance(this)
        if (mgr.isRequestPinAppWidgetSupported) {
            mgr.requestPinAppWidget(ComponentName(this, ClockWidgetProvider::class.java), null, null)
        } else {
            Toast.makeText(
                this,
                "اضغط مطولاً على الشاشة الرئيسية ثم اختر الأدوات وابحث عن أشكال الساعة",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}

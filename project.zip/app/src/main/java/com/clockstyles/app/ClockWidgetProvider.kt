package com.clockstyles.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.RemoteViews

class ClockWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        for (id in ids) update(context, mgr, id)
        schedule(context)
    }

    override fun onAppWidgetOptionsChanged(
        context: Context, mgr: AppWidgetManager, id: Int, newOptions: Bundle
    ) {
        update(context, mgr, id)
    }

    override fun onEnabled(context: Context) {
        schedule(context)
    }

    override fun onDisabled(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(tickIntent(context))
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val a = intent.action
        if (a == ACTION_TICK || a == Intent.ACTION_TIME_CHANGED || a == Intent.ACTION_TIMEZONE_CHANGED) {
            updateAll(context)
            schedule(context)
        }
    }

    companion object {
        const val ACTION_TICK = "com.clockstyles.app.TICK"

        private fun tickIntent(ctx: Context): PendingIntent {
            val i = Intent(ctx, ClockWidgetProvider::class.java)
            i.action = ACTION_TICK
            return PendingIntent.getBroadcast(
                ctx, 1, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        }

        fun schedule(ctx: Context) {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val next = (System.currentTimeMillis() / 60000L + 1L) * 60000L
            try {
                am.setExact(AlarmManager.RTC, next, tickIntent(ctx))
            } catch (e: SecurityException) {
                am.set(AlarmManager.RTC, next, tickIntent(ctx))
            }
        }

        fun updateAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, ClockWidgetProvider::class.java))
            for (id in ids) update(ctx, mgr, id)
        }

        fun update(ctx: Context, mgr: AppWidgetManager, id: Int) {
            val opts = mgr.getAppWidgetOptions(id)
            val density = ctx.resources.displayMetrics.density
            val wDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250)
            val hDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 150)
            var w = (wDp * density).toInt().coerceAtLeast(100)
            var h = (hDp * density).toInt().coerceAtLeast(60)
            val maxPx = 1000000L
            if (w.toLong() * h > maxPx) {
                val f = Math.sqrt(maxPx.toDouble() / (w.toLong() * h).toDouble())
                w = (w * f).toInt()
                h = (h * f).toInt()
            }
            val bmp = Renderer.render(ctx, Prefs.style(ctx), w, h)
            val rv = RemoteViews(ctx.packageName, R.layout.widget_clock)
            rv.setImageViewBitmap(R.id.img, bmp)
            val pi = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            rv.setOnClickPendingIntent(R.id.img, pi)
            mgr.updateAppWidget(id, rv)
        }
    }
}

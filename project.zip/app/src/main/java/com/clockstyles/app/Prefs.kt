package com.clockstyles.app

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("clockstyles", Context.MODE_PRIVATE)

    fun styleId(c: Context): String = sp(c).getString("style", Styles.all[0].id) ?: Styles.all[0].id

    fun setStyle(c: Context, id: String) {
        sp(c).edit().putString("style", id).apply()
    }

    fun style(c: Context): ClockStyle = Styles.byId(styleId(c))

    fun arabic(c: Context): Boolean = sp(c).getBoolean("arabic", false)

    fun setArabic(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("arabic", v).apply()
    }
}

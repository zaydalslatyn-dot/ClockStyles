package com.clockstyles.app

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("clockstyles", Context.MODE_PRIVATE)

    fun styleId(c: Context): String = sp(c).getString("style", Styles.all[0].id) ?: Styles.all[0].id

    fun setStyle(c: Context, id: String) {
        sp(c).edit().putString("style", id).apply()
    }

    fun style(c: Context): ClockStyle = Styles.byId(styleId(c))

    fun arabic(c: Context): Boolean = sp(c).getBoolean("arabic", false)

    fun setArabic(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("arabic", v).apply()
    }

    fun color(c: Context): Int? =
        if (sp(c).getBoolean("color_on", false)) sp(c).getInt("color", 0xFFFFFFFF.toInt()) else null

    fun setColor(c: Context, col: Int) {
        sp(c).edit().putBoolean("color_on", true).putInt("color", col).apply()
    }

    fun clearColor(c: Context) {
        sp(c).edit().putBoolean("color_on", false).apply()
    }

    fun hue(c: Context): Int = sp(c).getInt("hue", 40)

    fun setHue(c: Context, v: Int) {
        sp(c).edit().putInt("hue", v).apply()
    }

    fun shade(c: Context): Int = sp(c).getInt("shade", 50)

    fun setShade(c: Context, v: Int) {
        sp(c).edit().putInt("shade", v).apply()
    }
}

package com.clockstyles.app

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var list: LinearLayout
    private lateinit var preview: ImageView
    private val gold = 0xFFD4AF37.toInt()
    private val match = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(fill: Int, stroke: Int, strokeW: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = dp(16).toFloat()
        if (strokeW > 0) g.setStroke(strokeW, stroke)
        return g
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(0xFF0E0E10.toInt())
        scroll.layoutDirection = View.LAYOUT_DIRECTION_RTL

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(36), dp(16), dp(28))
        scroll.addView(root, ViewGroup.LayoutParams(match, wrap))

        val title = TextView(this)
        title.text = "أشكال الساعة"
        title.textSize = 24f
        title.setTextColor(Color.WHITE)
        title.typeface = Typeface.DEFAULT_BOLD
        root.addView(title)

        preview = ImageView(this)
        preview.background = rounded(0xFF5F645A.toInt(), 0, 0)
        preview.scaleType = ImageView.ScaleType.FIT_CENTER
        preview.setPadding(dp(8), dp(8), dp(8), dp(8))
        val plp = LinearLayout.LayoutParams(match, dp(200))
        plp.topMargin = dp(16)
        root.addView(preview, plp)

        val sw = Switch(this)
        sw.text = "أرقام عربية"
        sw.setTextColor(Color.WHITE)
        sw.isChecked = Prefs.arabic(this)
        sw.setOnCheckedChangeListener { _, v ->
            Prefs.setArabic(this, v)
            ClockWidgetProvider.updateAll(this)
            refresh()
        }
        val slp = LinearLayout.LayoutParams(match, wrap)
        slp.topMargin = dp(16)
        root.addView(sw, slp)

        val add = Button(this)
        add.text = "إضافة الويدجت للشاشة الرئيسية"
        add.setOnClickListener { pin() }
        val alp = LinearLayout.LayoutParams(match, wrap)
        alp.topMargin = dp(12)
        root.addView(add, alp)

        val sec = TextView(this)
        sec.text = "اضغط على أي شكل وتتحدث الساعة مباشرة"
        sec.textSize = 14f
        sec.setTextColor(0xFF9A9BA0.toInt())
        val tlp = LinearLayout.LayoutParams(match, wrap)
        tlp.topMargin = dp(20)
        root.addView(sec, tlp)

        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        root.addView(list, LinearLayout.LayoutParams(match, wrap))

        setContentView(scroll)
        refresh()
    }

    private fun refresh() {
        val cur = Prefs.styleId(this)
        preview.setImageBitmap(Renderer.render(this, Prefs.style(this), dp(340), dp(180)))
        list.removeAllViews()
        for (st in Styles.all) {
            val sel = st.id == cur
            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            card.background = rounded(0xFF1B1B1D.toInt(), gold, if (sel) dp(2) else 0)
            card.setPadding(dp(10), dp(10), dp(10), dp(10))

            val img = ImageView(this)
            img.setImageBitmap(Renderer.render(this, st, dp(300), dp(120)))
            card.addView(img, LinearLayout.LayoutParams(match, dp(120)))

            val tv = TextView(this)
            tv.text = (if (sel) "✓ " else "") + st.name
            tv.textSize = 14f
            tv.setTextColor(if (sel) gold else Color.WHITE)
            val vlp = LinearLayout.LayoutParams(match, wrap)
            vlp.topMargin = dp(6)
            card.addView(tv, vlp)

            card.setOnClickListener {
                Prefs.setStyle(this, st.id)
                ClockWidgetProvider.updateAll(this)
                refresh()
            }

            val clp = LinearLayout.LayoutParams(match, wrap)
            clp.topMargin = dp(10)
            list.addView(card, clp)
        }
    }

    private fun pin() {
        val mgr = AppWidgetManager.getInstance(this)
        if (mgr.isRequestPinAppWidgetSupported) {
            mgr.requestPinAppWidget(ComponentName(this, ClockWidgetProvider::class.java), null, null)
        } else {
            Toast.makeText(
                this,
                "اضغط مطولاً على الشاشة الرئيسية ثم اختر الأدوات وابحث عن أشكال الساعة",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}

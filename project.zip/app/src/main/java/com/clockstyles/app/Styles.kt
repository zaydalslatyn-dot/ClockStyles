package com.clockstyles.app

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.os.BatteryManager
import java.util.Calendar

object Digits {
    private const val AR = "٠١٢٣٤٥٦٧٨٩"

    fun conv(s: String, arabic: Boolean): String {
        if (!arabic) return s
        val sb = StringBuilder()
        for (ch in s) {
            if (ch in '0'..'9') sb.append(AR[ch - '0']) else sb.append(ch)
        }
        return sb.toString()
    }
}

data class Weather(val temp: Int, val min: Int, val max: Int, val desc: String)

object WeatherStore {
    var current: Weather? = null
}

class ClockState(cal: Calendar, val arabic: Boolean, val battery: Int, val weather: Weather?) {
    private val hour24: Int = cal.get(Calendar.HOUR_OF_DAY)
    val h12: Int = if (hour24 % 12 == 0) 12 else hour24 % 12
    val minute: Int = cal.get(Calendar.MINUTE)
    val ampm: String = if (hour24 >= 12) "م" else "ص"
    val day: Int = cal.get(Calendar.DAY_OF_MONTH)
    val dayName: String = DAYS[cal.get(Calendar.DAY_OF_WEEK) - 1]
    val monthName: String = MONTHS[cal.get(Calendar.MONTH)]

    fun dg(s: String): String = Digits.conv(s, arabic)

    fun pct(n: Int): String = dg(n.toString()) + (if (arabic) "٪" else "%")

    val time: String
        get() = dg(h12.toString() + ":" + minute.toString().padStart(2, '0'))

    val hh: String
        get() = dg(h12.toString().padStart(2, '0'))

    val mm: String
        get() = dg(minute.toString().padStart(2, '0'))

    val date: String
        get() = dayName + "، " + dg(day.toString()) + " " + monthName

    val wxShort: String
        get() = if (weather != null) "  ·  " + dg(weather.temp.toString()) + "°" else ""

    companion object {
        val DAYS = arrayOf("الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت")
        val MONTHS = arrayOf(
            "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
            "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
        )
    }
}

object Draw {
    fun alpha(c: Int, a: Int): Int = (c and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

    fun lum(c: Int): Float =
        (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f

    fun on(c: Int): Int = if (lum(c) > 0.6f) 0xFF111111.toInt() else 0xFFFFFFFF.toInt()

    fun mix(a: Int, b: Int, t: Float): Int {
        val r = (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt()
        val g = (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt()
        val bl = (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
        return Color.argb(255, r, g, bl)
    }

    fun shadeColor(hue: Int, shade: Int): Int {
        val t = shade / 100f
        val hv = hue.toFloat()
        return if (t < 0.5f) {
            Color.HSVToColor(floatArrayOf(hv, 1f, t / 0.5f))
        } else {
            Color.HSVToColor(floatArrayOf(hv, 1f - (t - 0.5f) / 0.5f, 1f))
        }
    }

    fun face(name: String, style: Int = Typeface.NORMAL): Typeface = Typeface.create(name, style)

    fun p(color: Int, size: Float, face: Typeface, align: Paint.Align = Paint.Align.LEFT): Paint {
        val pt = Paint(Paint.ANTI_ALIAS_FLAG)
        pt.color = color
        pt.textSize = size
        pt.typeface = face
        pt.textAlign = align
        if (lum(color) > 0.35f) pt.setShadowLayer(size * 0.06f + 2f, 0f, size * 0.02f + 1f, 0x55000000)
        return pt
    }

    fun aspect(text: String): Float {
        var d = 0
        var colon = false
        for (ch in text) {
            if (ch.isDigit()) d++ else if (ch == ':') colon = true
        }
        if (d == 0) return 0.5f
        return 0.26f * d + (if (colon) 0.13f else 0f)
    }

    fun fit(box: RectF, aspect: Float, mode: Int = 0): RectF {
        var rw = box.width()
        var rh = rw / aspect
        if (rh > box.height()) {
            rh = box.height()
            rw = rh * aspect
        }
        val cx = when (mode) {
            1 -> box.left + rw / 2f
            2 -> box.right - rw / 2f
            else -> box.centerX()
        }
        return RectF(cx - rw / 2f, box.centerY() - rh / 2f, cx + rw / 2f, box.centerY() + rh / 2f)
    }

    fun tall(c: Canvas, text: String, r: RectF, vararg ps: Paint) {
        if (ps.isEmpty()) return
        for (q in ps) q.textSize = 200f
        val b = Rect()
        ps[0].getTextBounds(text, 0, text.length, b)
        if (b.width() <= 0 || b.height() <= 0) return
        c.save()
        c.translate(r.left, r.top)
        c.scale(r.width() / b.width(), r.height() / b.height())
        for (q in ps) c.drawText(text, -b.left.toFloat(), -b.top.toFloat(), q)
        c.restore()
    }

    fun stack(c: Canvas, a: String, b: String, box: RectF, gap: Float, mode: Int, vararg ps: Paint) {
        val lh = (box.height() - gap) / 2f
        val b1 = RectF(box.left, box.top, box.right, box.top + lh)
        val b2 = RectF(box.left, box.top + lh + gap, box.right, box.bottom)
        tall(c, a, fit(b1, aspect(a), mode), *ps)
        tall(c, b, fit(b2, aspect(b), mode), *ps)
    }

    fun fitSize(pt: Paint, text: String, maxW: Float, maxH: Float) {
        pt.textSize = 100f
        val tw = pt.measureText(text)
        val b = Rect()
        pt.getTextBounds(text, 0, text.length, b)
        var sz = 100f * maxW / maxOf(tw, 1f)
        val bh = maxOf(b.height(), 1).toFloat()
        sz = minOf(sz, 100f * maxH / bh)
        pt.textSize = sz
    }

    fun center(c: Canvas, text: String, cx: Float, cy: Float, pt: Paint) {
        val b = Rect()
        pt.getTextBounds(text, 0, text.length, b)
        c.drawText(text, cx, cy - (b.top + b.bottom) / 2f, pt)
    }

    fun ring(c: Canvas, cx: Float, cy: Float, r: Float, pct: Int, col: Int) {
        val bg = Paint(Paint.ANTI_ALIAS_FLAG)
        bg.style = Paint.Style.STROKE
        bg.strokeWidth = r * 0.28f
        bg.color = alpha(col, 80)
        c.drawCircle(cx, cy, r, bg)
        val fg = Paint(bg)
        fg.color = col
        fg.strokeCap = Paint.Cap.ROUND
        c.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), -90f, 360f * pct.coerceIn(0, 100) / 100f, false, fg)
    }

    fun bar(c: Canvas, x: Float, y: Float, wd: Float, ht: Float, pct: Int, col: Int) {
        val t = Paint(Paint.ANTI_ALIAS_FLAG)
        t.color = alpha(col, 80)
        c.drawRoundRect(RectF(x, y, x + wd, y + ht), ht / 2f, ht / 2f, t)
        val f = Paint(Paint.ANTI_ALIAS_FLAG)
        f.color = col
        c.drawRoundRect(RectF(x, y, x + wd * pct.coerceIn(0, 100) / 100f, y + ht), ht / 2f, ht / 2f, f)
    }

    fun line(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, col: Int, wd: Float) {
        val l = Paint(Paint.ANTI_ALIAS_FLAG)
        l.color = col
        l.strokeWidth = wd
        l.strokeCap = Paint.Cap.ROUND
        c.drawLine(x1, y1, x2, y2, l)
    }
}

abstract class ClockStyle(val id: String, val name: String, val defColor: Int) {
    abstract fun draw(c: Canvas, w: Float, h: Float, s: ClockState, col: Int)
}

// 1-6: أرقام طويلة بأنواع مختلفة
class TallStyle(
    id: String,
    name: String,
    def: Int,
    private val faceName: String,
    private val faceStyle: Int,
    private val fillA: Int,
    private val strokeA: Int
) : ClockStyle(id, name, def) {
    override fun draw(c: Canvas, w: Float, h: Float, s: ClockState, col: Int) {
        val d = Draw.p(Draw.alpha(col, 235), h * 0.09f, Draw.face("sans-serif-medium"), Paint.Align.CENTER)
        c.drawText(s.date + s.wxShort, w / 2f, h * 0.12f, d)
        val box = RectF(w * 0.04f, h * 0.17f, w * 0.96f, h * 0.96f)
        val r = Draw.fit(box, Draw.aspect(s.time))
        val ps = ArrayList<Paint>()
        if (fillA > 0) ps.add(Draw.p(Draw.alpha(col, fillA), 200f, Draw.face(faceName, faceStyle)))
        if (strokeA > 0) {
            val st = Draw.p(Draw.alpha(col, strokeA), 200f, Draw.face(faceName, faceStyle))
            st.clearShadowLayer()
            st.style = Paint.Style.STROKE
            st.strokeWidth = 3f
            ps.add(st)
        }
        Draw.tall(c, s.time, r, *ps.toTypedArray())
    }
}

// 7
class StackThin : ClockStyle("stack_thin", "نحيف مكدّس مع بطارية", 0xFFEEEEEE.toInt()) {
    override fun draw(c: Canvas, w: Float, h: Float, s: ClockState, col: Int) {
        val gap = h * 0.03f
        val box = RectF(w * 0.1f, h * 0.03f, w * 0.9f, h * 0.70f)
        val pt = Draw.p(col, 200f, Draw.face("sans-serif-thin"))
        Draw.stack(c, s.hh, s.mm, box, gap, 0, pt)
        val d = Draw.p(Draw.alpha(col, 235), h * 0.08f, Draw.face("sans-serif-medium"), Paint.Align.CENTER)
        c.drawText(s.date, w / 2f, h * 0.80f, d)
        val rr = h * 0.045f
        val cx = w / 2f - h * 0.08f
        val cy = h * 0.915f
        Draw.ring(c, cx, cy, rr, s.battery, col)
        val bt = Draw.p(col, h * 0.06f, Draw.face("sans-serif"), Paint.Align.LEFT)
        Draw.center(c, s.pct(s.battery), cx + rr * 2f, cy, bt)
    }
}

// 8
class StackBold : ClockStyle("stack_bold", "عريض مكدّس مع طقس", 0xFF111111.toInt()) {
    override fun draw(c: Canvas, w: Float, h: Float, s: ClockState, col: Int) {
        val x0 = w * 0.08f
        val wx = s.weather
        val top = if (wx != null) s.dg(wx.temp.toString()) + "°" else s.dg(s.day.toString())
        val tp = Draw.p(col, h * 0.13f, Draw.face("sans-serif-black"))
        c.drawText(top, x0, h * 0.16f, tp)
        if (wx != null) {
            val dp = Draw.p(Draw.alpha(col, 220), h * 0.06f, Draw.face("sans-serif"))
            c.drawText(wx.desc, x0 + tp.measureText(top) + h * 0.03f, h * 0.16f, dp)
        }
        val dash = Paint(Paint.ANTI_ALIAS_FLAG)
        dash.color = col
        dash.style = Paint.Style.STROKE
        dash.strokeWidth = h * 0.008f + 1f
        dash.pathEffect = DashPathEffect(floatArrayOf(h * 0.025f, h * 0.02f), 0f)
        c.drawLine(x0, h * 0.215f, w * 0.92f, h * 0.215f, dash)
        val dm = Draw.p(col, h * 0.065f, Draw.face("sans-serif-medium"))
        c.drawText(s.dayName + " " + s.monthName, x0, h * 0.30f, dm)
        val box = RectF(x0, h * 0.34f, w * 0.75f, h * 0.98f)
        val pt = Draw.p(col, 200f, Draw.face("sans-serif-condensed", Typeface.BOLD))
        Draw.stack(c, s.hh, s.mm, box, h * 0.03f, 1, pt)
    }
}

// 9
class OutlineWide : ClockStyle("outline_wide", "مفرّغ بحدود", 0xFF444444.toInt()) {
    override fun draw(c: Canvas, w: Float, h: Float, s: ClockState, col: Int) {
        val d = Draw.p(Draw.alpha(col, 235), h * 0.085f, Draw.face("sans-serif-medium"), Paint.Align.CENTER)
        c.drawText(s.date, w / 2f, h * 0.15f, d)
        val pt = Draw.p(col, 100f, Draw.face("sans-serif", Typeface.BOLD), Paint.Align.CENTER)
        Draw.fitSize(pt, s.time, w * 0.9f, h * 0.55f)
        pt.clearShadowLayer()
        pt.style = Paint.Style.STROKE
        pt.strokeWidth = pt.textSize * 0.035f
        Draw.center(c, s.time, w / 2f, h * 0.56f, pt)
        val wx = s.weather
        if (wx != null) {
            val wp = Draw.p(Draw.alpha(col, 230), h * 0.08f, Draw.face("sans-serif"), Paint.Align.CENTER)
            c.drawText(s.dg(wx.temp.toString()) + "° " + wx.desc, w / 2f, h * 0.93f, wp)
        }
    }
}

// 10
class BlackBold : ClockStyle("black_bold", "أسود عريض مع طقس", 0xFF111111.toInt()) {
    override fun draw(c: Canvas, w: Float, h: Float, s: ClockState, col: Int) {
        val d = Draw.p(Draw.alpha(col, 235), h * 0.085f, Draw.face("sans-serif-medium"), Paint.Align.CENTER)
        c.drawText(s.date, w / 2f, h * 0.15f, d)
        val pt = Draw.p(col, 100f, Draw.face("sans-serif-black"), Paint.Align.CENTER)
        Draw.fitSize(pt, s.time, w * 0.9f, h * 0.55f)
        Draw.center(c, s.time, w / 2f, h * 0.57f, pt)
        val wx = s.weather
        if (wx != null) {
            val wp = Draw.p(col, h * 0.09f, Draw.face("sans-serif-medium"), Paint.Align.CENTER)
            c.drawText(s.dg(wx.temp.toString()) + "° " + wx.desc, w / 2f, h * 0.93f, wp)
        }
    }
}

// 11
class DayBig : ClockStyle("day_big", "يوم كبير مع طقس", 0xFF111111.toInt()) {
    override fun draw(c: Canvas, w: Float, h: Float, s: ClockState, col: Int) {
        val x0 = w * 0.06f
        val wx = s.weather
        if (wx != null) {
            c.drawText(s.dg(wx.temp.toString()) + "°", x0, h * 0.30f, Draw.p(col, h * 0.13f, Draw.face("sans-serif-medium")))
            c.drawText(wx.desc, x0, h * 0.40f, Draw.p(Draw.alpha(col, 210), h * 0.07f, Draw.face("sans-serif")))
        }
        val pill = RectF(x0, h * 0.5f, x0 + w * 0.13f, h * 0.66f)
        val fp = Paint(Paint.ANTI_ALIAS_FLAG)
        fp.color = col
        c.drawRoundRect(pill, h * 0.08f, h * 0.08f, fp)
        Draw.center(c, s.ampm, pill.centerX(), pill.centerY(), Draw.p(Draw.on(col), h * 0.09f, Draw.face("sans-serif", Typeface.BOLD), Paint.Align.CENTER))
        c.drawText(s.mm, pill.right + w * 0.02f, pill.bottom, Draw.p(col, h * 0.17f, Draw.face("sans-serif", Typeface.BOLD)))
        Draw.line(c, w * 0.46f, h * 0.12f, w * 0.46f, h * 0.70f, col, h * 0.01f + 1f)
        val hp = Draw.p(col, 100f, Draw.face("sans-serif-black"), Paint.Align.CENTER)
        Draw.fitSize(hp, s.hh, w * 0.45f, h * 0.62f)
        Draw.center(c, s.hh, w * 0.73f, h * 0.41f, hp)
        c.drawText(s.dayName, w * 0.73f, h * 0.90f, Draw.p(col, h * 0.13f, Draw.face("sans-serif", Typeface.BOLD), Paint.Align.CENTER))
    }
}

// 12
class TopPanel : ClockStyle("panel", "لوحة علوية مع مرحباً", 0xFFD6D6D6.toInt()) {
    override fun draw(c: Canvas, w: Float, h: Float, s: ClockState, col: Int) {
        val ph = h * 0.62f
        val rr = h * 0.08f
        val path = Path()
        path.addRoundRect(RectF(w * 0.03f, 0f, w * 0.97f, ph), floatArrayOf(0f, 0f, 0f, 0f, rr, rr, rr, rr), Path.Direction.CW)
        val fp = Paint(Paint.ANTI_ALIAS_FLAG)
        fp.color = col
        c.drawPath(path, fp)
        val ink = Draw.on(col)
        c.drawText(s.date, w / 2f, ph * 0.20f, Draw.p(ink, h * 0.07f, Draw.face("sans-serif-medium"), Paint.Align.CENTER))
        val pt = Draw.p(ink, 100f, Draw.face("sans-serif", Typeface.BOLD), Paint.Align.CENTER)
        Draw.fitSize(pt, s.time, w * 0.8f, ph * 0.46f)
        Draw.center(c, s.time, w / 2f, ph * 0.54f, pt)
        c.drawText("مرحباً", w * 0.22f, ph * 0.90f, Draw.p(ink, h * 0.065f, Draw.face("sans-serif", Typeface.BOLD), Paint.Align.CENTER))
        c.drawText(s.pct(s.battery), w * 0.78f, ph * 0.90f, Draw.p(ink, h * 0.065f, Draw.face("sans-serif"), Paint.Align.CENTER))
    }
}

// 13
class WhiteBattery : ClockStyle("white_battery", "أبيض مع بطارية", 0xFFFFFFFF.toInt()) {
    override fun draw(c: Canvas, w: Float, h: Float, s: ClockState, col: Int) {
        val d = Draw.p(Draw.alpha(col, 235), h * 0.085f, Draw.face("sans-serif-medium"), Paint.Align.CENTER)
        c.drawText(s.date, w / 2f, h * 0.15f, d)
        val pt = Draw.p(col, 100f, Draw.face("sans-serif-black"), Paint.Align.CENTER)
        Draw.fitSize(pt, s.time, w * 0.9f, h * 0.5f)
        Draw.center(c, s.time, w / 2f, h * 0.48f, pt)
        c.drawText("جوالي " + s.pct(s.battery), w / 2f, h * 0.80f, Draw.p(col, h * 0.07f, Draw.face("sans-serif"), Paint.Align.CENTER))
        Draw.bar(c, w * 0.3f, h * 0.86f, w * 0.4f, h * 0.035f, s.battery, col)
    }
}

// 14
class BlocksStyle : ClockStyle("blocks", "مربعات عملاقة", 0xFF111111.toInt()) {
    override fun draw(c: Canvas, w: Float, h: Float, s: ClockState, col: Int) {
        val wx = s.weather
        val label = s.dayName + " — " + (if (wx != null) wx.desc + " " + s.dg(wx.temp.toString()) + "°" else s.dg(s.day.toString()) + " " + s.monthName)
        c.save()
        c.translate(w * 0.1f, h * 0.5f)
        c.rotate(-90f)
        c.drawText(label, 0f, 0f, Draw.p(col, h * 0.055f, Draw.face("sans-serif-medium"), Paint.Align.CENTER))
        c.restore()
        val pt = Draw.p(col, 200f, Draw.face("sans-serif-black"))
        Draw.stack(c, s.hh, s.mm, RectF(w * 0.2f, h * 0.03f, w * 0.97f, h * 0.97f), h * 0.03f, 2, pt)
    }
}

// 15
class CurrentStyle : ClockStyle("current", "شكلك الحالي", 0xFFFFFFFF.toInt()) {
    override fun draw(c: Canvas, w: Float, h: Float, s: ClockState, col: Int) {
        val wx = s.weather
        val tp = Draw.p(col, 100f, Draw.face("sans-serif-light"), Paint.Align.LEFT)
        if (wx != null) {
            val lx = w * 0.2f
            c.drawText(s.dg(wx.temp.toString()) + "°", lx, h * 0.5f, Draw.p(col, h * 0.2f, Draw.face("sans-serif"), Paint.Align.CENTER))
            c.drawText(s.dg(wx.min.toString()) + "° / " + s.dg(wx.max.toString()) + "°", lx, h * 0.62f, Draw.p(Draw.alpha(col, 220), h * 0.07f, Draw.face("sans-serif"), Paint.Align.CENTER))
            Draw.line(c, w * 0.4f, h * 0.28f, w * 0.4f, h * 0.66f, Draw.alpha(col, 200), h * 0.01f + 1f)
            c.drawText(s.ampm, w * 0.415f, h * 0.48f, Draw.p(col, h * 0.07f, Draw.face("sans-serif")))
            Draw.fitSize(tp, s.time, w * 0.46f, h * 0.42f)
            Draw.center(c, s.time, w * 0.49f, h * 0.46f, tp)
            c.drawText(s.date, w * 0.5f, h * 0.82f, Draw.p(col, h * 0.08f, Draw.face("sans-serif-medium"), Paint.Align.CENTER))
        } else {
            tp.textAlign = Paint.Align.CENTER
            Draw.fitSize(tp, s.time, w * 0.7f, h * 0.45f)
            Draw.center(c, s.time, w / 2f, h * 0.42f, tp)
            val tw = tp.measureText(s.time)
            c.drawText(s.ampm, w / 2f - tw / 2f - h * 0.03f, h * 0.45f, Draw.p(col, h * 0.08f, Draw.face("sans-serif"), Paint.Align.RIGHT))
            c.drawText(s.date, w / 2f, h * 0.75f, Draw.p(col, h * 0.09f, Draw.face("sans-serif-medium"), Paint.Align.CENTER))
        }
    }
}

// 16
class AnalogStyle : ClockStyle("analog", "ساعة عقارب كلاسيكية", 0xFFFFFFFF.toInt()) {
    private fun hand(c: Canvas, cx: Float, cy: Float, deg: Float, len: Float, wid: Float, col: Int) {
        val a = Math.toRadians(deg.toDouble())
        Draw.line(c, cx, cy, cx + (Math.sin(a) * len).toFloat(), cy - (Math.cos(a) * len).toFloat(), col, wid)
    }

    override fun draw(c: Canvas, w: Float, h: Float, s: ClockState, col: Int) {
        val r = minOf(w, h) / 2f * 0.92f
        val cx = w / 2f
        val cy = h / 2f
        val ring = Paint(Paint.ANTI_ALIAS_FLAG)
        ring.style = Paint.Style.STROKE
        ring.color = Draw.alpha(col, 110)
        ring.strokeWidth = r * 0.012f + 1f
        c.drawCircle(cx, cy, r, ring)
        for (i in 0 until 12) {
            val a = Math.toRadians(i * 30.0)
            val major = i % 3 == 0
            val r1 = r * (if (major) 0.74f else 0.84f)
            val r2 = r * 0.94f
            val sx = Math.sin(a).toFloat()
            val sy = Math.cos(a).toFloat()
            Draw.line(c, cx + sx * r1, cy - sy * r1, cx + sx * r2, cy - sy * r2, col, r * (if (major) 0.045f else 0.022f))
        }
        Draw.center(c, s.dg(s.day.toString()), cx, cy + r * 0.45f, Draw.p(Draw.alpha(col, 210), r * 0.14f, Draw.face("sans-serif-medium"), Paint.Align.CENTER))
        hand(c, cx, cy, (s.h12 % 12 + s.minute / 60f) * 30f, r * 0.5f, r * 0.07f, col)
        hand(c, cx, cy, s.minute * 6f, r * 0.76f, r * 0.05f, col)
        val dot = Paint(Paint.ANTI_ALIAS_FLAG)
        dot.color = col
        c.drawCircle(cx, cy, r * 0.05f, dot)
    }
}

// 17
class SoftStyle : ClockStyle("soft", "رقم ناعم مجسّم", 0xFFC8C8C8.toInt()) {
    override fun draw(c: Canvas, w: Float, h: Float, s: ClockState, col: Int) {
        val pt = Draw.p(col, 100f, Draw.face("sans-serif-medium", Typeface.BOLD), Paint.Align.CENTER)
        Draw.fitSize(pt, s.time, w * 0.9f, h * 0.6f)
        val st = Draw.p(Draw.alpha(Draw.mix(col, 0xFFFFFFFF.toInt(), 0.6f), 160), pt.textSize, Draw.face("sans-serif-medium", Typeface.BOLD), Paint.Align.CENTER)
        st.clearShadowLayer()
        st.style = Paint.Style.STROKE
        st.strokeWidth = pt.textSize * 0.014f + 1f
        Draw.center(c, s.time, w / 2f, h * 0.45f, pt)
        Draw.center(c, s.time, w / 2f, h * 0.45f, st)
        c.drawText(s.date, w / 2f, h * 0.88f, Draw.p(Draw.alpha(col, 235), h * 0.09f, Draw.face("sans-serif-medium"), Paint.Align.CENTER))
    }
}

// 18
class BlockStack : ClockStyle("block_stack", "مكعّب عريض مكدّس", 0xFF111111.toInt()) {
    override fun draw(c: Canvas, w: Float, h: Float, s: ClockState, col: Int) {
        val fill = Draw.p(col, 200f, Draw.face("sans-serif-black"))
        val st = Draw.p(col, 200f, Draw.face("sans-serif-black"))
        st.clearShadowLayer()
        st.style = Paint.Style.STROKE
        st.strokeWidth = 6f
        Draw.stack(c, s.hh, s.mm, RectF(w * 0.1f, h * 0.03f, w * 0.9f, h * 0.80f), h * 0.03f, 0, fill, st)
        val wx = s.weather
        val tail = if (wx != null) "  ·  " + s.dg(wx.temp.toString()) + "°" else ""
        c.drawText(s.date + tail, w / 2f, h * 0.93f, Draw.p(col, h * 0.075f, Draw.face("sans-serif", Typeface.BOLD), Paint.Align.CENTER))
    }
}

// 19
class SlantedStyle : ClockStyle("slanted", "مائل ثقيل", 0xFF3E5070.toInt()) {
    override fun draw(c: Canvas, w: Float, h: Float, s: ClockState, col: Int) {
        val pt = Draw.p(col, 100f, Draw.face("sans-serif", Typeface.BOLD_ITALIC), Paint.Align.CENTER)
        Draw.fitSize(pt, s.time, w * 0.82f, h * 0.48f)
        c.save()
        c.translate(w / 2f, h * 0.55f)
        c.skew(-0.2f, 0f)
        c.drawText(s.time, 0f, 0f, pt)
        c.restore()
        c.drawText(s.date, w / 2f, h * 0.72f, Draw.p(Draw.alpha(col, 235), h * 0.08f, Draw.face("sans-serif-medium"), Paint.Align.CENTER))
        c.drawText("جوالي " + s.pct(s.battery), w / 2f, h * 0.86f, Draw.p(col, h * 0.06f, Draw.face("sans-serif"), Paint.Align.CENTER))
        Draw.bar(c, w * 0.3f, h * 0.90f, w * 0.4f, h * 0.03f, s.battery, col)
    }
}

// 20
class FlipSmall : ClockStyle("flip_small", "قلب صغير", 0xFF7A7A7A.toInt()) {
    override fun draw(c: Canvas, w: Float, h: Float, s: ClockState, col: Int) {
        val th = minOf(h * 0.62f, w * 0.2f * 1.6f)
        val tw = th / 1.6f
        val gap = tw * 0.12f
        val mid = tw * 0.35f
        val total = 4f * tw + 2f * gap + mid
        var x = (w - total) / 2f
        val y = (h - th) / 2f
        val digits = listOf(s.hh[0], s.hh[1], s.mm[0], s.mm[1])
        val fp = Paint(Paint.ANTI_ALIAS_FLAG)
        fp.color = col
        val dp = Draw.p(Draw.on(col), th * 0.62f, Draw.face("sans-serif"), Paint.Align.CENTER)
        dp.clearShadowLayer()
        for (i in 0 until 4) {
            val rect = RectF(x, y, x + tw, y + th)
            c.drawRoundRect(rect, tw * 0.16f, tw * 0.16f, fp)
            Draw.center(c, digits[i].toString(), rect.centerX(), rect.centerY(), dp)
            Draw.line(c, rect.left, rect.centerY(), rect.right, rect.centerY(), 0x99000000.toInt(), 2f)
            x += tw + (if (i == 1) mid else gap)
        }
    }
}

// 21
class SerifStyle : ClockStyle("serif", "سيريف أنيق مع طقس وسماعات", 0xFFCFCFCF.toInt()) {
    override fun draw(c: Canvas, w: Float, h: Float, s: ClockState, col: Int) {
        c.drawText(s.date, w / 2f, h * 0.13f, Draw.p(Draw.alpha(col, 235), h * 0.085f, Draw.face("sans-serif-medium"), Paint.Align.CENTER))
        val pt = Draw.p(col, 100f, Typeface.create(Typeface.SERIF, Typeface.BOLD), Paint.Align.CENTER)
        Draw.fitSize(pt, s.time, w * 0.8f, h * 0.42f)
        Draw.center(c, s.time, w / 2f, h * 0.45f, pt)
        c.drawText("جوالي " + s.pct(s.battery), w * 0.08f, h * 0.78f, Draw.p(col, h * 0.065f, Draw.face("sans-serif")))
        Draw.bar(c, w * 0.08f, h * 0.84f, w * 0.38f, h * 0.035f, s.battery, col)
        val wx = s.weather
        if (wx != null) {
            c.drawText(s.dg(wx.temp.toString()) + "° " + wx.desc, w * 0.92f, h * 0.78f, Draw.p(col, h * 0.065f, Draw.face("sans-serif"), Paint.Align.RIGHT))
            c.drawText("أعلى " + s.dg(wx.max.toString()) + "° أدنى " + s.dg(wx.min.toString()) + "°", w * 0.92f, h * 0.88f, Draw.p(Draw.alpha(col, 200), h * 0.055f, Draw.face("sans-serif"), Paint.Align.RIGHT))
        }
    }
}

// 22
class FlipBig : ClockStyle("flip_big", "قلب كبير", 0xFF1B1B1B.toInt()) {
    override fun draw(c: Canvas, w: Float, h: Float, s: ClockState, col: Int) {
        val cw = minOf(w * 0.46f, h * 0.98f)
        val ch = minOf(h * 0.92f, cw)
        val gap = w * 0.04f
        val x0 = (w - (2f * cw + gap)) / 2f
        val y = (h - ch) / 2f
        val fp = Paint(Paint.ANTI_ALIAS_FLAG)
        fp.color = col
        val ink = Draw.on(col)
        val texts = listOf(s.h12.toString().let { s.dg(it) }, s.mm)
        for (i in 0 until 2) {
            val rect = RectF(x0 + i * (cw + gap), y, x0 + i * (cw + gap) + cw, y + ch)
            c.drawRoundRect(rect, ch * 0.08f, ch * 0.08f, fp)
            val dp = Draw.p(ink, 100f, Draw.face("sans-serif", Typeface.BOLD), Paint.Align.CENTER)
            dp.clearShadowLayer()
            Draw.fitSize(dp, texts[i], cw * 0.8f, ch * 0.55f)
            Draw.center(c, texts[i], rect.centerX(), rect.centerY(), dp)
            Draw.line(c, rect.left, rect.centerY(), rect.right, rect.centerY(), 0xCC000000.toInt(), 2f)
        }
        c.drawText(s.ampm, x0 + cw * 0.08f, y + ch * 0.92f, Draw.p(ink, ch * 0.09f, Draw.face("sans-serif-medium")))
    }
}

object Styles {
    val all: List<ClockStyle> = listOf(
        TallStyle("tall", "أرقام ضخمة طويلة", 0xFFFFFFFF.toInt(), "sans-serif-condensed", Typeface.BOLD, 238, 0),
        TallStyle("tall_blue", "أزرق طويل", 0xFF3B8BE6.toInt(), "sans-serif-condensed", Typeface.BOLD, 238, 0),
        TallStyle("tall_outline", "رفيع طويل مفرّغ", 0xFFEEEEEE.toInt(), "sans-serif-condensed-light", Typeface.NORMAL, 70, 255),
        TallStyle("tall_fog", "زجاجي ضبابي طويل", 0xFFFFFFFF.toInt(), "sans-serif-condensed-light", Typeface.NORMAL, 150, 90),
        TallStyle("tall_glass", "زجاجي أبيض طويل", 0xFFFFFFFF.toInt(), "sans-serif-condensed-light", Typeface.NORMAL, 225, 120),
        TallStyle("tall_metal", "معدني رمادي طويل", 0xFF8A8A8A.toInt(), "sans-serif-condensed", Typeface.NORMAL, 255, 0),
        StackThin(),
        StackBold(),
        OutlineWide(),
        BlackBold(),
        DayBig(),
        TopPanel(),
        WhiteBattery(),
        BlocksStyle(),
        CurrentStyle(),
        AnalogStyle(),
        SoftStyle(),
        BlockStack(),
        SlantedStyle(),
        FlipSmall(),
        SerifStyle(),
        FlipBig()
    )

    fun byId(id: String): ClockStyle = all.firstOrNull { it.id == id } ?: all[0]
}

object Renderer {
    fun battery(ctx: Context): Int {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val l = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        return if (l < 0 || sc <= 0) 0 else l * 100 / sc
    }

    fun render(ctx: Context, style: ClockStyle, w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val col = Prefs.color(ctx) ?: style.defColor
        val st = ClockState(Calendar.getInstance(), Prefs.arabic(ctx), battery(ctx), WeatherStore.current)
        style.draw(c, w.toFloat(), h.toFloat(), st, col)
        return bmp
    }
}

package com.clockstyles.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import java.util.Calendar

object Digits {
    private const val AR = "٠١٢٣٤٥٦٧٨٩"

    fun conv(s: String, arabic: Boolean): String {
        if (!arabic) return s
        val sb = StringBuilder()
        for (ch in s) {
            if (ch in '0'..'9') sb.append(AR[ch - '0']) else sb.append(ch)
        }
        return sb.toString()
    }
}

class ClockState(cal: Calendar, val arabic: Boolean) {
    private val hour24: Int = cal.get(Calendar.HOUR_OF_DAY)
    val h12: Int = if (hour24 % 12 == 0) 12 else hour24 % 12
    val minute: Int = cal.get(Calendar.MINUTE)
    val ampm: String = if (hour24 >= 12) "م" else "ص"
    val day: Int = cal.get(Calendar.DAY_OF_MONTH)
    val dayName: String = DAYS[cal.get(Calendar.DAY_OF_WEEK) - 1]
    val monthName: String = MONTHS[cal.get(Calendar.MONTH)]

    fun dg(s: String): String = Digits.conv(s, arabic)

    val time: String
        get() = dg(h12.toString() + ":" + minute.toString().padStart(2, '0'))

    val date: String
        get() = dayName + "، " + dg(day.toString()) + " " + monthName

    companion object {
        val DAYS = arrayOf("الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت")
        val MONTHS = arrayOf(
            "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
            "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
        )
    }
}

object Draw {
    fun fit(box: RectF, aspect: Float): RectF {
        var rw = box.width()
        var rh = rw / aspect
        if (rh > box.height()) {
            rh = box.height()
            rw = rh * aspect
        }
        return RectF(
            box.centerX() - rw / 2, box.centerY() - rh / 2,
            box.centerX() + rw / 2, box.centerY() + rh / 2
        )
    }

    fun tall(c: Canvas, text: String, r: RectF, p: Paint) {
        val b = Rect()
        p.textSize = 200f
        p.getTextBounds(text, 0, text.length, b)
        if (b.width() <= 0 || b.height() <= 0) return
        c.save()
        c.translate(r.left, r.top)
        c.scale(r.width() / b.width(), r.height() / b.height())
        c.drawText(text, -b.left.toFloat(), -b.top.toFloat(), p)
        c.restore()
    }
}

abstract class ClockStyle(val id: String, val name: String) {
    abstract fun draw(c: Canvas, w: Float, h: Float, s: ClockState)
}

class TallStyle(
    id: String,
    name: String,
    private val digitColor: Int,
    private val dateColor: Int
) : ClockStyle(id, name) {
    override fun draw(c: Canvas, w: Float, h: Float, s: ClockState) {
        val dateP = Paint(Paint.ANTI_ALIAS_FLAG)
        dateP.color = dateColor
        dateP.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        dateP.textAlign = Paint.Align.CENTER
        dateP.textSize = h * 0.09f
        dateP.setShadowLayer(6f, 0f, 1f, 0x66000000)
        c.drawText(s.date, w / 2, h * 0.12f, dateP)

        val box = RectF(w * 0.04f, h * 0.17f, w * 0.96f, h * 0.96f)
        val digits = s.time.count { it.isDigit() }
        val r = Draw.fit(box, 0.26f * (digits + 0.5f))
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = digitColor
        p.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        p.setShadowLayer(12f, 0f, 2f, 0x55000000)
        Draw.tall(c, s.time, r, p)
    }
}

class SimpleStyle : ClockStyle("simple", "بسيط مع تاريخ") {
    override fun draw(c: Canvas, w: Float, h: Float, s: ClockState) {
        val tp = Paint(Paint.ANTI_ALIAS_FLAG)
        tp.color = 0xFFFFFFFF.toInt()
        tp.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        tp.textAlign = Paint.Align.CENTER
        tp.textSize = minOf(h * 0.5f, w * 0.27f)
        tp.setShadowLayer(8f, 0f, 2f, 0x66000000)
        val baseline = h * 0.62f
        c.drawText(s.time, w / 2, baseline, tp)

        val timeW = tp.measureText(s.time)
        val ap = Paint(Paint.ANTI_ALIAS_FLAG)
        ap.color = 0xFFFFFFFF.toInt()
        ap.textAlign = Paint.Align.RIGHT
        ap.textSize = h * 0.1f
        ap.setShadowLayer(6f, 0f, 1f, 0x66000000)
        c.drawText(s.ampm, w / 2 - timeW / 2 - h * 0.03f, baseline, ap)

        val dp = Paint(Paint.ANTI_ALIAS_FLAG)
        dp.color = 0xFFEEEEEE.toInt()
        dp.textAlign = Paint.Align.CENTER
        dp.textSize = h * 0.11f
        dp.setShadowLayer(6f, 0f, 1f, 0x66000000)
        c.drawText(s.date, w / 2, baseline + h * 0.17f, dp)
    }
}

object Styles {
    val all: List<ClockStyle> = listOf(
        TallStyle("tall", "أرقام ضخمة طويلة", 0xEEFFFFFF.toInt(), 0xFFE6E6E6.toInt()),
        TallStyle("tall_blue", "أزرق طويل", 0xFF3B8BE6.toInt(), 0xFF7FB2F0.toInt()),
        SimpleStyle()
    )

    fun byId(id: String): ClockStyle = all.firstOrNull { it.id == id } ?: all[0]
}

object Renderer {
    fun render(ctx: Context, style: ClockStyle, w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        style.draw(c, w.toFloat(), h.toFloat(), ClockState(Calendar.getInstance(), Prefs.arabic(ctx)))
        return bmp
    }
}
